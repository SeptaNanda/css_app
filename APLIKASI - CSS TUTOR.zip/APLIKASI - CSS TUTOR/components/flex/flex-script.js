// justify-content
$(document).ready(function(){
	$("#showDiv1").click(function(){
		$("#myDiv1").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv2").click(function(){
		$("#myDiv2").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv3").click(function(){
		$("#myDiv3").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv4").click(function(){
		$("#myDiv4").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv5").click(function(){
		$("#myDiv5").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv6").click(function(){
		$("#myDiv6").toggle();
	});
});
// align-items
// align-items
// align-items
$(document).ready(function(){
	$("#showDiv11").click(function(){
		$("#myDiv11").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv12").click(function(){
		$("#myDiv12").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv13").click(function(){
		$("#myDiv13").toggle();
	});
});
// flex-direction
// flex-direction
// flex-direction
$(document).ready(function(){
	$("#showDiv21").click(function(){
		$("#myDiv21").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv22").click(function(){
		$("#myDiv22").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv23").click(function(){
		$("#myDiv23").toggle();
	});
});
$(document).ready(function(){
	$("#showDiv24").click(function(){
		$("#myDiv24").toggle();
	});
});